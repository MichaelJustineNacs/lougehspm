<!DOCTYPE html>
<html lang="en">
<head>
    <!--
        ===
        Charisma v2.0.0

        Copyright 2012-2014 Muhammad Usman
        Licensed under the Apache License v2.0
        http://www.apache.org/licenses/LICENSE-2.0

        http://usman.it
        http://twitter.com/halalit_usman
        ===
    -->
    <meta charset="utf-8">
    <title>Lou Geh Supermarket</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Charisma, a fully featured, responsive, HTML5, Bootstrap admin template.">
    <meta name="author" content="Muhammad Usman">

    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-cybrog.min.css" rel="stylesheet">

    <link href="css/charisma-app.css" rel="stylesheet">
    <link href='bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>
    <link href='css/noty_theme_default.css' rel='stylesheet'>
    <link href='css/elfinder.min.css' rel='stylesheet'>
    <link href='css/elfinder.theme.css' rel='stylesheet'>
    <link href='css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='css/uploadify.css' rel='stylesheet'>
    <link href='css/animate.min.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>

    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The fav icon -->
    <link rel="shortcut icon" href="img/market.png">

</head>

<body>
    <!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php"> <img alt="Charisma Logo" src="img/market.png" class="hidden-xs"/>
                LouGeh Supermarket</a>

            </div>
          
            </div>
         
        </div>
    </div>
    <!-- topbar ends -->
<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">

                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        <li class="nav-header">Main</li>
                        <li><a class="ajax-link" href="index.php"><i class="glyphicon glyphicon-home"></i><span> TRANSACTION </span></a>
                        </li>
                        <li><a class="ajax-link" href="items.php"><i class="glyphicon glyphicon-list-alt"></i><span> ITEMS</span></a>
                        </li>
                        
                        <li><a class="ajax-link" href="customers.php"><i class="glyphicon glyphicon-list-alt"></i><span> CUSTOMERS</span></a>
                        </li>
                        <li><a class="ajax-link" href="suppliers.php"><i class="glyphicon glyphicon-font"></i><span> SUPPLIERS</span></a>
                        </li>
                        <li><a class="ajax-link" href="print.php"><i class="glyphicon glyphicon-picture"></i><span> ORDER</span></a>
                        </li>
                      
                    </ul>
                    
                </div>
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div class="col-md-10">
                <ul class="breadcrumb">
                    <li>
                        <a href="#">Home</a>
                    </li>
                    <li>
                        <a href="#">Transactions</a>
                    </li>
                </ul>

            </div>
                
            <br>
            <div class="row">
            <div class="box col-md-6">
            <div class="box-inner">
            <div class="box-header well">
                <h2><i class="glyphicon glyphicon-info-sign"></i> Sales Transactions</h2>
                
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">
                        <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Timestamp</th>
                            <th>Customer</th>
                            <th>Total Amount</th>
                            <th width="5">View</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                                include('config.php');

                                function convert($toConvert){
                                    return number_format($toConvert, 2);
                                }

                                $query = mysqli_query($conn, "SELECT transaction_time, customer_id FROM sales_trans GROUP BY transaction_time ORDER BY transaction_time DESC");
                                $numrows = mysqli_num_rows($query);
                                if ($numrows != 0) {
                                    $cnt = 1;
                                    while ($row = mysqli_fetch_array($query)) {
                                        $tran_time = $row['transaction_time'];
                                        $customer_id = $row['customer_id'];

                                        $query2 = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = '$customer_id'");
                                        $row2 = mysqli_fetch_array($query2);
                                        $customer_name = $row2['customer_firstname']." ".$row2['customer_mi'].". ".$row2['customer_lastname'];

                                        $query3 = mysqli_query($conn, "SELECT SUM(total) as 'grand' FROM sales_trans WHERE transaction_time = '$tran_time'");
                                        $row3 = mysqli_fetch_array($query3);
                                        $grand = convert($row3['grand']);

                                        echo "<tr>";
                                        echo "<td>$cnt</td>";
                                        echo "<td>$tran_time</td>";
                                        echo "<td>$customer_name</td>";
                                        echo "<td>₱ $grand</td>";
                                       echo "<td><a href='viewsales.php?tt=$tran_time' class='btn btn-primary btn-xs'><i class='glyphicon glyphicon-eye-open'></i></a></td>";
                                        echo "</tr>";

                                        $cnt++;
                                    }
                                }
                                else{
                            ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php } ?>

                        </tbody>
                        </table>
                        </div>
                </div>
            </div>
             </div>
              </div>
            <div class="box col-md-6">
            <div class="box-inner">
            <div class="box-header well">
                <h2><i class="glyphicon glyphicon-info-sign"></i> Delivery Transactions</h2>
            </div>
            <div class="box-content row">
                <div class="col-lg-12 col-md-12">
                     <div class="box-content">
                        <table class="table table-striped table-bordered bootstrap-datatable datatable responsive" id="delivery">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Timestamp</th>
                            <th>Supplier</th>
                            <th>Total Amount</th>
                            <th width="5">View</th>
                        </tr>
                        </thead>
                        <tbody>
                       
                             <?php
                                $query = mysqli_query($conn, "SELECT transaction_time, supplier_id FROM delivery_trans GROUP BY transaction_time ORDER BY transaction_time DESC");
                                $numrows = mysqli_num_rows($query);
                                if ($numrows != 0) {
                                    $cnt = 1;
                                    while ($row = mysqli_fetch_array($query)) {
                                        $tran_time2 = $row['transaction_time'];
                                        $supplier_id = $row['supplier_id'];

                                        $query2 = mysqli_query($conn, "SELECT * FROM suppliers WHERE supplier_id = '$supplier_id'");
                                        $row2 = mysqli_fetch_array($query2);
                                        $company_name = $row2['company_name'];

                                        $query3 = mysqli_query($conn, "SELECT SUM(total) as 'grand' FROM delivery_trans WHERE transaction_time = '$tran_time2'");
                                        $row3 = mysqli_fetch_array($query3);
                                        $grand2 = convert($row3['grand']);

                                        echo "<tr>";
                                        echo "<td>$cnt</td>";
                                        echo "<td>$tran_time2</td>";
                                        echo "<td>$company_name</td>";
                                        echo "<td>₱ $grand2</td>";
                                        echo "<td><a href='viewdelivery.php?tt=$tran_time2' class='btn btn-primary btn-xs'><i class='glyphicon glyphicon-eye-open'></i></a></td>";
                                        echo "</tr>";

                                        $cnt++;
                                    }
                                }
                                else{
                            ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php } ?>
                        
                        </tbody>
                        </table>
                        </div>
                </div>
            </div>
            
        </div>
        
    </div>
    <div class="col-md-2">
                
                <a href="newtransaction.php" class="btn btn-primary btn-round btn-lg"><i class="glyphicon glyphicon-plus"></i> New Transaction</a>
                </div>
</div>


    
</div><!--/row-->



<!-- external javascript -->

<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>


</body>
</html>
