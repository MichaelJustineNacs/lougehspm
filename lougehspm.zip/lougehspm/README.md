Lou Geh Supermarket Transaction System

A Guide on how to use the System. Unfinished and Retoke.

1. Install XAMPP.
2. Download and extract the folder to your xampp installation directory - "xampp/htdocs".
3. Import the "loughspm.sql" file in the assets folder into MySql Database / PHPMyAdmin. 
4. Configure "config.php" with your severname,username, and password on your preferred Database. 
5. Open your XAMPP and start Apache and MySql.
6. Open any browser and enter "localhost/lougehspm".

A mix of working,unfinished and slight remodel of the system. A Mixed Emotion.