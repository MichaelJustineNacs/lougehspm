<?php
	include('config.php');

	$ntid = $_REQUEST['ntid'];

	mysqli_query($conn, "DELETE FROM item WHERE barcode = '$ntid'");

	header("location:newitem.php")

?>