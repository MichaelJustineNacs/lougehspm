<!-- left menu starts -->
<div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">

                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        <li class="nav-header">Main</li>
                        <li><a class="ajax-link" href="index.php"><i class="glyphicon glyphicon-home"></i><span> TRANSACTION </span></a>
                        </li>
                        <li><a class="ajax-link" href="items.php"><i class="glyphicon glyphicon-list-alt"></i><span> ITEMS</span></a>
                        </li>
                        
                        <li><a class="ajax-link" href="customers.php"><i class="glyphicon glyphicon-list-alt"></i><span> CUSTOMERS</span></a>
                        </li>
                        <li><a class="ajax-link" href="suppliers.php"><i class="glyphicon glyphicon-font"></i><span> SUPPLIERS</span></a>
                        </li>
                        <li><a class="ajax-link" href="print.php"><i class="glyphicon glyphicon-picture"></i><span> ORDER</span></a>
                        </li>
                      
                    </ul>
                    
                </div>
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->