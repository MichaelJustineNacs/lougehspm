<div class="modal fade" id="newTransaction" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
           
        </div>
    </div>
</div>
<div class="modal fade" id="selectCustomer" role="dialog">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
           
        </div>
    </div>
</div>
<div class="modal fade" id="selectItem" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
           
        </div>
    </div>
</div>
<div class="modal fade" id="viewSales" role="dialog">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
           
        </div>
    </div>
</div>
<div class="modal fade" id="viewDelivery" role="dialog">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
           
        </div>
    </div>
</div>